public class Location{
    
    public Location(){
    
    }
    
    public static void creerLocation(){
        //Faire un location
        return;
    }
    
    public static void terminerLocation(){
        //Terminer un location
        return;
    }
}