public class Prepose{
    
    public Prepose(){
    
    }
    
    public static void AjouterPrepose(){
        //Ajouter un préposé
        return;
    }
    
    public static void RetirerPrepose(){
        //Retirer un préposé
        return;
    }
}