public class Compte{
    
    public Compte(){
        
    }

    public static void Connecter(String nom, String pass){
        //Connexion d'un compte, et mets les variables nécessaires avec une connection réussie
        return;
    }
    
    public static void Deconnecter(){
        //Déconnexion d'un compte
        return;
    }
    
    public static bool getPermission(String param){
        //Regarde si le compte connecté a la permission de faire l'action correspondante
        return false;
    }
    
    public void modifierCompte(){
        //Modifie et sauvegarde un compte
        return;
    }
    
    public void creerCompte(){
        //Crée un compte
        return;
    }
}