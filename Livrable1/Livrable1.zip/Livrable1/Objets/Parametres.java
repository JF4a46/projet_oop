public class Parametres{
    //mettre quelques variables statiques pour facilement accéder aux paramètres
    public String 
    //Ajouter d'autres variables

    public static Object getParametre(String param){
        //Obtenir le paramètre de la base de données
        return false;
    }
    
    public static Object modifierParametre(String param, Object donnee){
        //Changer un paramètre
        return false;
    }
}