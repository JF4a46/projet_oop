public class Paiement{
    
    public Paiement(){
    
    }
    
    public static void fairePaiement(){
        //Faire un paiement
        return;
    }
}