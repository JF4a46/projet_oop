public class CreationLocation{
    
    public static void rechercheVehicule(){
		
	}
	
	public static void selectionVehicule(){
		
	}
	
	public static void effectuerLocation(){
		
	}
	
	public static void retour(){
		
	}
}