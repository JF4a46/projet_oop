public class RechercheClient{
    
    public static void recherche(){
		
	}
	
	public static void retour(){
		
	}
}