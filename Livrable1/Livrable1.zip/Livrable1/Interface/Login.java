public class Login{
    
    public static void Login(){
		//Utiliser ID et mot de passe
	}
}