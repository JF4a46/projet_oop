public class Client{
    
    public static void connecterClient(){
		
	}
	
	public static void connecterClient(){
		//NOTE: Il faut ajouter ceci dans le prototype de l'interface.
	}
	
	public static void deconnexion(){
		
	}
}