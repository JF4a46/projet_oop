public class TerminerLocation{
	
	public static void selectionLocation(){
		
	}
	
	public static void terminerLocation(){
		
	}
	
	public static void retour(){
		
	}
}