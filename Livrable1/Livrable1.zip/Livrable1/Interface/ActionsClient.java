public class ActionsClient{
    
    public static void creerLocation(){
		
	}
	
	public static void creerReservation(){
		
	}
	
	public static void terminerLocation(){
		
	}
	
	public static void effectuerPaiement(){
		
	}
	
	public static void modifierClient(){
		
	}
	
	public static void retour(){
		
	}
}